#include <bits/stdc++.h>
#define max(a,b) ((a)>(b))?(a):(b)
int n,W;
int dp[101][10001];
int w[101],v[101];


int main(){
    scanf("%d %d",&n,&W);
    for (int i=0;i<n;i++){
        scanf("%d %d",&w[i],&v[i]);
    }
    for (int i=0;i<n;i++){
        for (int j=0;j<=W;j++){
            if (j<w[i])
                dp[i+1][j] = dp[i][j];
            else
                dp[i+1][j] = max(dp[i][j],dp[i+1][j-w[i]]+v[i]);
        }
    }
    printf("%d",dp[n][W]);

    return 0;
}
