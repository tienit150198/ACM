#include <iostream>
using namespace std;
int a[100][100],d,c;
void TaoMaTran()
{
  int trai=0,tren=0,phai=c,duoi=d,dem=0,soluong=c*d;
  while(dem<soluong)
  {
   for(int i=trai;i<phai;i++)
    if(dem<soluong)
       a[tren][i]=dem++;
           tren++;
   for(int i=tren;i<duoi;i++)
    if(dem<soluong)
       a[i][phai-1]=dem++;
           phai--;
   for(int i=phai-1;i>=trai;i--)
    if(dem<soluong)
       a[duoi-1][i]=dem++;
            duoi--;
   for(int i=duoi-1;i>=tren;i--)
    if(dem<soluong)
       a[i][trai]=dem++;
         trai++;
  }
}
void XuatMaTran()
{
  for(int i=0;i<d;i++)
  {
  for(int j=0;j<c;j++){
  	cout<<a[i][j]<<" ";
  }
  cout<<endl;
  }
}
int  main()
{
 cin>>d;
 c = d;
 TaoMaTran();
 XuatMaTran();
}
