#include <bits/stdc++.h>
using namespace std;
int k,n;
int a[7];
long s = 1;
void xuat(){
    for (int i=1; i<=n; i++){
        cout<<a[i];
    }
}
void xuly(int i){
    for (int j=1; j<=k; j++){
        a[i] = j;
        if (i==n){
            xuat();
            cout<<endl;
        }else{
            xuly(i+1);
        }
    }
}

int main(){
    cin>>k>>n;
    for (int i=0; i<n; i++){
        s*=k; }
    cout<<s<<endl;
    xuly(1);
    return 0;
}

