#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>

using namespace std;

const int MAX_N = 50000;

int N, K;

int parent[MAX_N * 3];
int height[MAX_N * 3];

void init() {
    for (int i = 0; i < 3 * N; i++) {
        parent[i] = i;
        height[i] = 0;
    }
}

int find(int a) {
    if (parent[a] == a)
        return a;
    return parent[a] = find(parent[a]);
}

void unite(int a, int b) {
    a = find(a);
    b = find(b);
    if (a == b)
        return;
    if (height[a] < height[b])
        parent[a] = b;
    else {
        parent[b] = a;
        if (height[a] == height[b]) height[a]++;
    }
}

bool same(int a, int b) {
    return find(a) == find(b);
}

int main() {
    scanf("%d %d", &N, &K);

    init();

    int cnt = 0;
    for (int i = 0; i < K; i++) {
        int query, x, y;
        scanf("%d %d %d", &query, &x, &y);
        x--; y--;

        if (x < 0 || x >= N || y < 0 || y >= N) {
            cnt++;
            continue;
        }

        if (query == 1) {
            if (same(x, y + N) || same(x, y + 2 * N)) {
                cnt++;
                continue;
            }

            unite(x, y);
            unite(x + N, y + N);
            unite(x + 2 * N, y + 2 * N);
        }
        else {
            if (same(x, y) || same(x, y + 2 * N) ||
                same(x + N, y + N) || same(x + N, y) ||
                same(x + 2 * N, y + 2 * N) || same(x + 2 * N, y + N)) {
                cnt++;
                continue;
            }

            unite(x, y + N);
            unite(x + N, y + 2 * N);
            unite(x + 2 * N, y);
        }
    }

    printf("%d", cnt);

    return 0;
}
