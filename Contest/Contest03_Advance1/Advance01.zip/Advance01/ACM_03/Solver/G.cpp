#include <bits/stdc++.h>

using namespace std;

#define MAX_ARR 1000001

long long esp[MAX_ARR],s[MAX_ARR],n,i,t;

void Calc()
{
	memset(esp,0,sizeof(esp));
	memset(s,0,sizeof(s));
	esp[1]=1; long long j;
	for (long long i=2;i<=MAX_ARR;i++)
    {
		if (esp[i]==0)
        {
			esp[i]=i-1; 
			j=2*i;
			while (j<=MAX_ARR)
        	{
        		if (esp[j]==0) esp[j]=j;
        		esp[j]-=esp[j]/i;
        		j+=i;
        	}
    	}
	}
	for (long long i=1;i<=MAX_ARR;i++)
	{
		j=2*i;
		while (j<=MAX_ARR)
    	{
			s[j]+=i*esp[j/i];
        	j+=i;
    	}
	}
	for (long long i=1;i<=MAX_ARR;i++) s[i]+=s[i-1];
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(NULL); cout.tie(NULL);
	Calc();
	cin>>t;
	for (long long i=1;i<=t;i++)
	{
		cin>>n;
		cout<<s[n]<<"\n";
	}
}
