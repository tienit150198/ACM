import java.util.Arrays;
import java.util.Scanner;


public class Main {
    private static int n ,r,current=0;
    private static int[] array;
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
        current =0;
        r = scanner.nextInt();
        n = scanner.nextInt();
        array = new int[n];
        for (int i = 0; i < array.length; i++) {
        array[i] = scanner.nextInt();
        }
        int i=0;
        Arrays.sort(array);
        while (i<n) {
        	int x = array[i++];
        	while (i<n&&x+r>=array[i]) i++;
        	int  p = array[i-1];
        	while (i<n&&p+r>=array[i]) i++;
        	current++;
        }
        System.out.print(current);

    scanner.close();
    }

}