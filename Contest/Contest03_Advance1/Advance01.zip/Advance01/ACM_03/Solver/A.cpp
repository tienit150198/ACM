#include <bits/stdc++.h>

using namespace std;

int n, r, curr;
int a[10005];


int main()
{
	curr = 0;
	cin>>n;
	cin>>r;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	sort(a, a + n);
	int i = 0;
	while(i < n){
		int x = a[i++];
		while(i<n && x + r >= a[i])i++;
		int p = a[i-1];
		while(i<n && p + r >= a[i])i++;
		curr++;
	}
	cout<<curr;
	return 0;
}
