#include <bits/stdc++.h>
#include <algorithm>
typedef long long ll;
int n;
int v1[1000],v2[1000];
using namespace std;
int main(){
    scanf("%d",&n);
    for (int i=0;i<n;i++)
        scanf("%d",&v1[i]);
    for (int i=0;i<n;i++)
        scanf("%d",&v2[i]);

    sort(v1,v1+n);
    sort(v2,v2+n);
    ll ans =0;
    for (int i=0;i<n;i++)
        ans+=(ll)v1[i]*v2[n-i-1];
    printf("%lld",ans);

    return 0;
}
